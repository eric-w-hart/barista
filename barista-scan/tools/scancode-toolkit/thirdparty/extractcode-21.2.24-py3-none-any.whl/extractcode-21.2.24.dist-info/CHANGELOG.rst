Release notes
=============

vNext
-----


Version 21.1.21
---------------

- Bump dependencies and use latest typecode and binaries. This is to fix
  installation problems on multiple OSes.


Version 21.1.21
---------------

- Add new [full] extra requires that install all the dependencies
- Fix bug related to commoncode libraries loading
- Improve the extra requirements
- Set minimum version for dependencies
- Improve documentation


Version 21.1.15
---------------

- Drop support for Python 2
- Use the latest CommonCode and TypeCode libraries
- Add azure-pipelines CI support


Version 20.10
-------------

- Initial release.
